package mx.ipn.escom.wad.tarea6.util;

public class NombreObjetosSession {
	public static final String USER = "authenticated_user";
	public static final String GLOBAL_MESSAGE = "global-message";
}
