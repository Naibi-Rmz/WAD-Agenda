package mx.ipn.escom.wad.tarea6.entidad;

public interface Modelo {
	public Integer getId();
	public void setId(Integer id);
}
